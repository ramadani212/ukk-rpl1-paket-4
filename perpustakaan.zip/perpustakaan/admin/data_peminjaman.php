<h4> 🛒 Data Peminjaman</h4>
<a href="?halaman=input_peminjaman" class="btn btn-secondary">
    ➕ Tambah Data Peminjaman
</a>

<table class="table table-bordered mt-3">
    <tr class="fw-bold">
        <td>No</td>
        <td>NIS</td>
        <td>Nama Anggota</td>
        <td>Judul buku</td>
        <td>Tanggal Pinjam</td>
        <td>Kelola</td>
    </tr>

<?php
include '../koneksi.php';
$no = 1;

// ✅ pakai LEFT JOIN biar data tetap muncul walau relasi bermasalah
$query = "SELECT * FROM transaksi 
LEFT JOIN buku ON buku.id_buku = transaksi.id_buku 
LEFT JOIN anggota ON anggota.id_anggota = transaksi.id_anggota
WHERE transaksi.status_transaksi = 'Peminjaman'
ORDER BY transaksi.id_transaksi DESC";

$data = mysqli_query($koneksi, $query);

// cek kalau tidak ada data
if(mysqli_num_rows($data) == 0){
    echo "<tr><td colspan='6' class='text-center'>Data tidak ada</td></tr>";
}

while($peminjam = mysqli_fetch_assoc($data)){
?>
    <tr>
        <td><?= $no++; ?></td> 
        <td><?= $peminjam['nis'] ?? '-'; ?></td>
        <td><?= $peminjam['nama_anggota'] ?? '-'; ?></td>
        <td><?= $peminjam['judul_buku'] ?? '-'; ?></td>
        <td><?= $peminjam['tgl_pinjam']; ?></td>
        <td>
            <?php
            $pesan = "✅ Pengembalian buku oleh {$peminjam['nama_anggota']}, Buku {$peminjam['judul_buku']}";
            $isi = "'$pesan',{$peminjam['id_transaksi']},{$peminjam['id_buku']}";
            ?>
            <a onclick="pengembalian(<?= $isi ?>)" class="btn btn-success">✅ Pengembalian</a>

            <?php
            $pesan = "🗑️ Anda yakin ingin menghapus buku oleh {$peminjam['nama_anggota']}, Buku {$peminjam['judul_buku']}";
            $isi = "'$pesan',{$peminjam['id_transaksi']},{$peminjam['id_buku']}";
            ?>
            <a onclick="hapus(<?= $isi ?>)" class="btn btn-danger">🗑️ Hapus</a> 
        </td>
    </tr>
<?php } ?>
</table>

<script>
function pengembalian(pesan,id_transaksi,id_buku){
    if(confirm(pesan)){
        window.location.href = '?halaman=proses_pengembalian&id='+id_transaksi+'&buku='+id_buku;
    }
}

function hapus(pesan,id_transaksi,id_buku){
    if(confirm(pesan)){
        window.location.href = '?halaman=hapus&id='+id_transaksi+'&buku='+id_buku;
    }
}
</script>