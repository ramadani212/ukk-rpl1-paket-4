<?php
$id = $_GET['id'];
$buku = $_GET['buku'];
date_default_timezone_set("Asia/Jakarta");
$tgl_kembali = date('Y-m-d H:i:s');
include'../koneksi.php';
$data = mysqli_query($koneksi, "DELETE FROM transaksi WHERE id_transaksi='$id'");
if($data){
    mysqli_query($koneksi, "UPDATE buku SET status='tersedia' WHERE id_buku='$buku'");
    echo"<script>alert('✅ Buku berhasil dihapus');window.location.assign('?halaman=data_peminjaman')</script>";
}else{
    echo "<script>alert('❌ Gagal menghapus data');window.location.assign('?halaman=data_peminjaman')</script>";
}
?>