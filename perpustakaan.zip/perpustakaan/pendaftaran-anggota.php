<!DOCTYPE html>
<html Lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, intial-scale=1.0">
        <title>Pendaftaran Anggota - Aplikasi Perpustakaan Sekolah Digital</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
    body {
        background-image: url("logo smk.jpg");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }
    .overlay {
        background-color: rgba(0,0,0,0.5);
        min-height: 100vh;
    }

    </style>
    </head>
    <body>
        <div class="overlay">
  <div class="d-flex justify-content-center align-items-center vh-100">
    <form method="post" action="" class="col-md-4 p-4 bg-white rounded-4 shadow">
      <img src="logo smk.jpg" width="80px" class="mx-auto d-block mb-3">
      <h4 class="text-center">Pendaftaran Anggota</h4>
      <p class="text-center text-muted mb-4">Aplikasi Perpustakaan Sekolah Digital</p>
      <input type="text" name="nis" class="form-control mb-3" placeholder="Masukan NIS" required>
      <input type="text" name="nama_anggota" class="form-control mb-3" placeholder="Masukan Nama Anggota" required>
      <input type="text" name="username" class="form-control mb-3" placeholder="Masukan Username" required>
      <input type="password" name="password" class="form-control mb-3" placeholder="Masukan Password" required>
      <input type="text" name="kelas" class="form-control mb-3" placeholder="Masukan Kelas" required>
      <button name="tombol" type="submit" class="btn btn-success w-100 mb-3">Daftar</button>
      <div class="text-center">
        <a href="login-anggota.php" class="d-block">Login Sebagai Anggota</a>
        <a href="login-admin.php" class="d-block">Login Sebagai Admin</a>
      </div>

    </form>

  </div>
</div>
    </body>
</html>
<?php
include 'koneksi.php';

if (isset($_POST['tombol'])) {

    $nis = $_POST['nis'];
    $nama_anggota = $_POST['nama_anggota'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $kelas = $_POST['kelas'];

    // enkripsi password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // cek username sudah ada atau belum
    $cek = mysqli_query($koneksi, "SELECT * FROM anggota WHERE username='$username'");
    if (mysqli_num_rows($cek) > 0) {
        echo "<script>alert('Username sudah digunakan!'); window.location='pendaftaran-anggota.php';</script>";
        exit;
    }

    // simpan ke database
    $query = mysqli_query($koneksi, "INSERT INTO anggota(nis,nama_anggota,username,password,kelas) 
                                    VALUES('$nis','$nama_anggota','$username','$password_hash','$kelas')");

    if ($query) {
        echo "<script>alert('Pendaftaran berhasil! Silakan login'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Pendaftaran gagal!');</script>";
    }
}
?>