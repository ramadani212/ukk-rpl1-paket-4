<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Anggota</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-dark d-flex justify-content-center align-items-center vh-100">

<div class="card p-4" style="width:420px;">
    <h3 class="text-center mb-3">Daftar Anggota</h3>

    <form action="proses_registrasi.php" method="POST">
        <div class="mb-3">
            <input type="email" name="email" class="form-control" placeholder="Email" required>
        </div>

        <div class="mb-3">
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>

        <div class="mb-3">
            <input type="password" name="konfirmasi_password" class="form-control" placeholder="Ulangi Password" required>
        </div>

        <input type="hidden" name="role" value="ANGGOTA">

        <button type="submit" class="btn btn-success w-100">Daftar</button>
    </form>

    <div class="text-center mt-3">
        Sudah punya akun? <a href="index.php">Login di sini</a>
    </div>
</div>

</body>
</html>